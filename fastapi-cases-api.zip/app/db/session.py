import os
import ssl
from pathlib import Path
from urllib.parse import urlparse

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from app.core.config import settings


def _should_use_ssl(db_url: str) -> bool:
    # Em Lambda sempre use SSL (RDS está com rds.force_ssl=1)
    if os.getenv("AWS_LAMBDA_FUNCTION_NAME"):
        return True

    # Se o host for RDS, use SSL também
    try:
        # urlparse não gosta do "+asyncpg", então normaliza
        parsed = urlparse(db_url.replace("postgresql+asyncpg://", "postgresql://"))
        host = parsed.hostname or ""
        if host.endswith(".rds.amazonaws.com"):
            return True
    except Exception:
        pass

    # Override manual (se quiser)
    if os.getenv("FORCE_DB_SSL") == "1":
        return True

    return False


def _build_ssl_context() -> ssl.SSLContext:
    # Se você definir essa env var, ela tem prioridade
    env_path = os.getenv("RDS_CA_FILE")

    candidates = [
        env_path,
        "/var/task/rds-ca.pem",       # raiz do zip da Lambda
        "/var/task/app/rds-ca.pem",   # se você copiar pra dentro de app/
        str(Path.cwd() / "rds-ca.pem"),
        str(Path(__file__).resolve().parents[2] / "rds-ca.pem"),  # repo root (local)
        str(Path(__file__).resolve().parents[1] / "rds-ca.pem"),  # app/ (local)
    ]

    for p in candidates:
        if p and Path(p).exists():
            return ssl.create_default_context(cafile=p)

    # fallback: ainda cria um contexto SSL usando o trust store do sistema
    return ssl.create_default_context()


connect_args = {}
if _should_use_ssl(settings.SQLALCHEMY_DATABASE_URI):
    connect_args = {"ssl": _build_ssl_context()}

# Configure async engine with connection pool settings
engine = create_async_engine(
    settings.SQLALCHEMY_DATABASE_URI,
    pool_pre_ping=True,
    pool_size=5,
    max_overflow=10,
    pool_timeout=30,
    pool_recycle=1800,
    echo=False,
    connect_args=connect_args,  # ✅ AQUI está a correção principal
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
    class_=AsyncSession
)

async def get_db():
    """Dependency to get database session"""
    async with SessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()

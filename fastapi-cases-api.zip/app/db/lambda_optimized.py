"""
Otimizações de banco de dados para AWS Lambda

Lambda reutiliza instâncias entre invocações (warm start).
Este módulo otimiza conexões para aproveitar isso.
"""
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)

# ============================================================
# VARIÁVEIS GLOBAIS - Reutilizadas entre invocações
# ============================================================
_engine = None
_async_session_maker = None

def get_lambda_engine():
    """
    Retorna engine otimizado para Lambda
    
    Benefícios:
    - Reutiliza engine entre invocações (warm start)
    - Pool otimizado (1 conexão por instância Lambda)
    - Pre-ping evita conexões stale
    """
    global _engine
    
    if _engine is None:
        logger.info("🔧 Criando novo engine SQLAlchemy para Lambda...")
        
        _engine = create_async_engine(
            settings.SQLALCHEMY_DATABASE_URI,
            
            # Desabilitar echo em produção
            echo=False,
            
            # CRÍTICO: Pre-ping verifica conexão antes de usar
            pool_pre_ping=True,
            
            # Lambda = 1 conexão simultânea por instância
            pool_size=1,
            max_overflow=0,
            
            # Reciclar conexões antigas (1 hora)
            pool_recycle=3600,
            
            # Timeout e configurações
            connect_args={
                "command_timeout": 30,
                "server_settings": {
                    "application_name": "lambda_fastapi_cases",
                    "jit": "off"
                }
            }
        )
        
        logger.info("✅ Engine criado!")
    else:
        logger.info("♻️  Reutilizando engine (warm start)")
    
    return _engine


def get_lambda_session_maker():
    """
    Retorna session maker otimizado
    """
    global _async_session_maker
    
    if _async_session_maker is None:
        logger.info("🔧 Criando session maker...")
        
        engine = get_lambda_engine()
        _async_session_maker = sessionmaker(
            engine, 
            class_=AsyncSession, 
            expire_on_commit=False,
            autoflush=False
        )
        
        logger.info("✅ Session maker criado!")
    
    return _async_session_maker


async def get_db_lambda():
    """
    Dependency otimizada para Lambda
    
    USO:
    ----
    from app.db.lambda_optimized import get_db_lambda
    
    @router.get("/items")
    async def get_items(db: AsyncSession = Depends(get_db_lambda)):
        # ... seu código ...
    """
    async_session_maker = get_lambda_session_maker()
    
    async with async_session_maker() as session:
        try:
            logger.debug("📊 Sessão aberta")
            yield session
        finally:
            logger.debug("📊 Sessão fechada")
            await session.close()


async def cleanup_connections():
    """
    Limpa todas as conexões
    Útil para testes ou forçar recriação
    """
    global _engine, _async_session_maker
    
    if _engine:
        logger.info("🧹 Limpando engine...")
        await _engine.dispose()
        _engine = None
        _async_session_maker = None
        logger.info("✅ Engine limpo!")
